-----------------------------------------------------------------
               DTCPing.exe v2.0
                  June 2009
  (c) Microsoft Corporation, 2009. All rights reserved.
------------------------------------------------------------------

To use the DTCPing.exe tool, you must follow these steps: 

1. Replace �A� and �B� with the appropriate NetBIOS name of your testing computers.

2. Input the name as is, without two forward slashes (//).  No Internet Protocol (IP) 
   addresses are permitted in testing.

3. Make sure that you have Read/Browse permissions on the HKEY_CLASSES_ROOT registry 
   key.

NOTE: There are two files for testing on each direction.


I.  Prepare DTCPing.exe 
    Copy the DTCPing.exe file to both Computer A and Computer B.

    If you receive any error message in "Test Network Connectivity" section, 
    copy the log file that is specified in the DTCping.exe window, and 
    then send two files on both Computer A and Computer B to Microsoft for 
    analysis.

II. Test Network Connectivity 
    1. On Computer A, run DTCPing.exe.

    2. On Computer B, run DTCPing.exe.

    3. On Computer A, type the NetBIOS name of Computer B, and then click Ping.

    4. On Computer B, type the NetBIOS name of Computer A, and then click Ping.

NOTE: The DTCPing log file can be found in the same folder as the DTCPing.exe file. 
The log file name has the following format: �NetBIOSName� + �ProcessID� + .log


III. Tool Functionality

The DTCPing.exe tool performs the following functions:

    * Tests name resolution.
      Because each Microsoft Distributed Transaction Coordinator (MS DTC) service 
      uses the NetBIOS name of its peer to talk to other MS DTC services, name 
      resolution is the first step toward MS DTC troubleshooting. The DTCPing.exe 
      tool first tries to resolve the computer network name to the IP address. 
      DTCPing.exe uses this IP address to obtain the host name.

    * Tests Remote Procedure Call (RPC) communication.
      RPC is the basis for MS DTC communication. The DTCPing.exe tool uses the 
      dynamic port with Transmission Control Protocol/Internet Protocol (TCP/IP) 
      protocol to test RPC communication. MSDTC requires successful, two-way RPC 
      communication to function. The DTCPing.exe tool also reports more details 
      if the host computer is running out of the TCP/IP port.

    * Logs the MS DTC settings.
      The DTCPing.exe tool logs MS DTC Security settings.

    * Tests DTC communication.
      MS DTC is based on two-way RPC and uses MS DTC Connection Manager protocol
      to establish connections. The DTCPing tool simulates MSDTC at the Connection 
      Manager level.

    * Logs the current adapter configuration (except on Microsoft Windows NT 4.0-based 
      systems).
 
    * Detects and logs the cluster configuration of MS DTC. 
      If the cluster environment is detected by the DTCPing.exe tool, the tool logs the 
      IP address resource and the name resource for MSDTC.
